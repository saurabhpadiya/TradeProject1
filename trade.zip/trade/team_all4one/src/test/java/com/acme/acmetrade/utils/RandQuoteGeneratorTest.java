package com.acme.acmetrade.utils;

import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.*;

public class RandQuoteGeneratorTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void quoteGeneratorValidFunctionTestSuccess() {
        QuoteGenIn quoteGenIn = new QuoteGenIn();
        int noOfDays = 3;
        LocalDate startDate = LocalDate.parse("2018-01-24");
        quoteGenIn.setStart_date(startDate);
        quoteGenIn.setNoOfDays(noOfDays);
        quoteGenIn.setFunctionId("1");
        List<StockQuote> stockQuotes=RandQuoteGenerator.quoteGenerator(quoteGenIn,160);
        Assert.assertEquals(stockQuotes.size(),noOfDays);
        quoteGenIn.setFunctionId("2");
        List<StockQuote> stockQuotes2=RandQuoteGenerator.quoteGenerator(quoteGenIn,160);
        Assert.assertEquals(stockQuotes2.size(),noOfDays);
        quoteGenIn.setFunctionId("3");
        List<StockQuote> stockQuotes3=RandQuoteGenerator.quoteGenerator(quoteGenIn,160);
        Assert.assertEquals(stockQuotes3.size(),noOfDays);
    }

    @Test
    public void quoteGeneratorInvalidFunctionTestSuccess() {
        QuoteGenIn quoteGenIn = new QuoteGenIn();
        int noOfDays = 3;
        LocalDate startDate = LocalDate.parse("2018-01-24");
        quoteGenIn.setStart_date(startDate);
        quoteGenIn.setNoOfDays(noOfDays);
        quoteGenIn.setFunctionId("4");
        List<StockQuote> stockQuotes=RandQuoteGenerator.quoteGenerator(quoteGenIn,160);
        Assert.assertEquals (160,stockQuotes.get(0).getOpenValue(),0.001);
    }


}