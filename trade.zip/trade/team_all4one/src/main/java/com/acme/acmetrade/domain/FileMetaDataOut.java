package com.acme.acmetrade.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import java.time.LocalDate;


@Entity
@Table(name = "QUOTE_METADATA")
public class FileMetaDataOut {

    @JsonProperty
    @Id
    @Column(name="ID")
    private String fileName;

    @JsonProperty
    @Column(name="NO_OF_DAYS")
    private int noOfDays;

    @JsonProperty
    @Column(name="START_DATE")
    private LocalDate start_date;

    @JsonProperty
    @Column(name="FUNCTION_ID")
    private String functionId;

    @JsonProperty
    @Column(name="STOCK_SYMBOL", columnDefinition = "VARCHAR(10)")
    SymbolEnum symbol;

    public FileMetaDataOut(String fileName, int noOfDays, LocalDate start_date, String functionId, SymbolEnum symbol) {
        this.fileName = fileName;
        this.noOfDays = noOfDays;
        this.start_date = start_date;
        this.functionId = functionId;
        this.symbol = symbol;
    }

    public int getNoOfDays() {
        return noOfDays;
    }

    public void setNoOfDays(int noOfDays) {
        this.noOfDays = noOfDays;
    }

    public LocalDate getStart_date() {
        return start_date;
    }

    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public SymbolEnum getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolEnum symbol) {
        this.symbol = symbol;
    }


    @Override
    public String toString() {
        return "FileMetaDataOut{" +
                "fileName='" + fileName + '\'' +
                ", noOfDays=" + noOfDays +
                ", start_date=" + start_date +
                ", functionId='" + functionId + '\'' +
                ", symbol=" + symbol +
                '}';
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
