package com.acme.acmetrade.utils;

import com.acme.acmetrade.domain.StockQuote;

import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.Stream;

public class FileUtils {

    public static void parse(Stream<StockQuote> lines, String output) throws IOException {
        final FileWriter fw = new FileWriter(output);

        lines.forEach(quo -> writeToFile(fw, quo));
        fw.close();
        lines.close();
    }

    private static void writeToFile(FileWriter fw, StockQuote quote) {
        try {
            //fw.write(String.format("%s%n", quote));
            fw.write(String.format("%s%n",quote.toStringForFile()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
