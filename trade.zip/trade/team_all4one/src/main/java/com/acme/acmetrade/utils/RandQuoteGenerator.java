package com.acme.acmetrade.utils;

import com.acme.acmetrade.common.ApplicationConstant;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class RandQuoteGenerator {

    public static List<StockQuote> quoteGenerator(QuoteGenIn quoteGenIn, double input) {

        String functionId = quoteGenIn.getFunctionId();
        Double generatedValue;
        int multiplier = getFunctionMultiplier(functionId);

        Double previousDayCloseValue = input + getValue(input, functionId);

        StockQuote stockQuote;
        List<StockQuote> stockQuotes = new ArrayList<>();
        for (int i = 0; i < quoteGenIn.getNoOfDays(); i++) {

            stockQuote = new StockQuote();
            generatedValue = getValue(input, functionId);

            //generate open value
            stockQuote.setOpenValue(input + generatedValue);

            //generate close value
            stockQuote.setCloseValue(input + generatedValue * multiplier);

            //generate high value
            stockQuote.setHighValue(stockQuote.getOpenValue() > stockQuote.getCloseValue() ? stockQuote.getOpenValue() + (generatedValue > 0 ? generatedValue : generatedValue * -1) : stockQuote.getCloseValue() + (generatedValue > 0 ? generatedValue : generatedValue * -1));

            //generate low value
            stockQuote.setLowValue(stockQuote.getOpenValue() < stockQuote.getCloseValue() ? stockQuote.getOpenValue() - (generatedValue > 0 ? generatedValue : generatedValue * -1) : stockQuote.getCloseValue() - (generatedValue > 0 ? generatedValue : generatedValue * -1));

            //generate volume value
            stockQuote.setVolume(Math.round((stockQuote.getOpenValue() + stockQuote.getCloseValue() + stockQuote.getHighValue() + stockQuote.getCloseValue()) * ApplicationConstant.VOLUME_MULTIPLIER));

            stockQuotes.add(stockQuote);
            input = stockQuote.getCloseValue();
        }

        return stockQuotes;
    }

    private static double getValue(double input, String functionId) {
        switch (functionId) {
            case "1":
                return Math.sin(input);
            case "2":
                return Math.cos(input);
            case "3":
                return Math.sin(input) + Math.cos(input);
            default:
                return 0.0;
        }
    }

    private static int getFunctionMultiplier(String functionId) {
        switch (functionId) {
            case "1":
                return ApplicationConstant.FUNCTION_1_MULTIPLIER;
            case "2":
                return ApplicationConstant.FUNCTION_2_MULTIPLIER;
            case "3":
                return ApplicationConstant.FUNCTION_3_MULTIPLIER;
            default:
                return 0;
        }
    }
}
