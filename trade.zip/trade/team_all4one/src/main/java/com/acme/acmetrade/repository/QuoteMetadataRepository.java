package com.acme.acmetrade.repository;

import com.acme.acmetrade.domain.FileMetaDataOut;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuoteMetadataRepository extends JpaRepository<FileMetaDataOut,String> {
    @Query("from FileMetaDataOut")
    List<FileMetaDataOut> getAllQuoteMetadata();
}

