package com.acme.acmetrade.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Value("${DB_DRIVER}")
    private String dbDriver;

    @Value("${DB_CONNECTION_DETAILS}")
    private String dbConnectionDetails;

    @Value("${DB_USER_ID}")
    private String dbUserId;

    @Value("${DB_USER_PASSWORD}")
    private String dbUserPassword;


    public Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException ex) {
            log.error(ex.toString());
        }
        try {
            connection = DriverManager.getConnection(dbConnectionDetails, dbUserId, dbUserPassword);
        }
        catch (SQLException ex){
            log.error(ex.toString());
        }
        return connection;
    }
}
