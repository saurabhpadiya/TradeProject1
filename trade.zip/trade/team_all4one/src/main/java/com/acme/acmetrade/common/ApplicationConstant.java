package com.acme.acmetrade.common;

public class ApplicationConstant {

    public static int FUNCTION_1_MULTIPLIER = 5;
    public static int FUNCTION_2_MULTIPLIER = 3;
    public static int FUNCTION_3_MULTIPLIER = 1;
    public static long VOLUME_MULTIPLIER = 100000;
    public static String DECIMALFORMAT ="#.##";
    public static int STANDARD_MULTIPLIER = 10;
}
