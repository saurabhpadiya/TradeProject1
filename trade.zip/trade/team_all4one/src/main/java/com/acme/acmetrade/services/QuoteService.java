package com.acme.acmetrade.services;

import com.acme.acmetrade.common.ApplicationConstant;
import com.acme.acmetrade.domain.FileMetaDataOut;
import com.acme.acmetrade.domain.QuoteGenIn;
import com.acme.acmetrade.domain.StockQuote;
import com.acme.acmetrade.domain.SymbolEnum;
import com.acme.acmetrade.utils.FileUtils;
import com.acme.acmetrade.utils.RandQuoteGenerator;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class QuoteService {

    public static List<StockQuote> generateQuote (QuoteGenIn quoteGenIn, SymbolEnum symbol, int initConstant) throws IOException {
        double x = initConstant;
        List<StockQuote> stockQuotes = RandQuoteGenerator.quoteGenerator(quoteGenIn,x);

        for (StockQuote stockQuote: stockQuotes) {

            //add symbol
            stockQuote.setSymbol(symbol);

            //add date

            LocalDate ldt = quoteGenIn.getStart_date().plusDays(stockQuotes.indexOf(stockQuote));
            //ldt.format(DateTimeFormatter.ofPattern("d-M-y"));

            stockQuote.setTxnDate(ldt.format(DateTimeFormatter.ofPattern("y-MM-dd")));

        }

        //write open a file and write to it
        String dateT = LocalDateTime.now().toString().replace(":","");
        String fileName = "C:/Users/student/Files/StockQuote_" + symbol.toString()+ "_"+ dateT + "_" +quoteGenIn.getNoOfDays() + ".csv";
        FileUtils.parse(stockQuotes.stream(),fileName);

        //generate FIle metaData



        return stockQuotes;
    }


}
